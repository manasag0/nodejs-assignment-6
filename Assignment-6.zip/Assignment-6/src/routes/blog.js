const router = require('express').Router();
const Blog = require('../models/Blog')

// Your routing code goes here

// getting data
router.get('/blog', async(req,res)=>{
    try{
        // console.log(req.query)
        const blog=await Blog.find({
            topic:req.query.search
            
        }).limit(req.query.Number(page-1 )* 5)
        res.json({
            status:"success",
            result: blog
        })
    }catch(e){
        res.json({
            error: e.message
        })
    }
})

// creating data
router.post('/blog', async(req,res)=>{
    console.log(req.body)
    try{
        const blog = await Blog.create(req.body)
        res.json({
            status: "success",
            result:blog
        })
    }catch(e){
        res.json({
            status:"failed",
            message:e.message
        })

    }
   
})
// updating data
router.put("/blog/:id",async (req,res)=>{
    try{
        const blog = await Blog.updateOne({_id:req.params.id},req.body)
        res.json({
            status: "success",
            result:blog
        })
    }catch(e){
        res.json({
            status:"failed",
            message:e.message
        })
    }
})
  
router.delete("/blog/:id",async (req,res)=>{
    try{
        const blog = await Blog.deleteOne({_id:req.params.id})
        res.json({
            status: "success",
            result:blog
        })
    }catch(e){
        res.json({
            status:"failed",
            message:e.message
        })
    }
})
                

module.exports = router;